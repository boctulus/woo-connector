<?php

return array (
  'type' => 'variable',
  'name' => 'Pantalones elefante-like ******+',
  //'slug' => 'pantalones-tipo-elefante',
  'status' => 'publish',
  //'featured' => false,
  'catalog_visibility' => 'visible',
  'description' => 'bla bla bla tipo elefanteeeee ***+',
  'short_description' => 'desc corta ******',
  'sku' => 'elefante-panta-1',
  'price' => '2220000',
  'regular_price' => '',
  'sale_price' => '11000000',
  'manage_stock' => true,
  'stock_quantity' => 99900,
  'stock_status' => 'instock',
  'is_sold_individually' => true,
  'weight' => '66',
  'length' => '77',
  'width' => '88',
  'height' => '99',
  'parent_id' => 0,
  'tags' => 
  array (
    0 => 
    (object) array(
       'name' => 'Tag unooooo',
       'slug' => 'tag-uno',
    ),
    1 => 
    (object) array(
       'name' => 'Tag dosssss',
       'slug' => 'tag-dos',
    ),
  ),
  'categories' => 
  array (
    0 => 
    array (
      'name' => 'Pantalonesssssss',
      'slug' => 'pantalones',
      'description' => '',
    ),
    1 => 
    array (
      'name' => 'Ropa de modaaaaaa',
      'slug' => 'ropa-de-moda',
      'description' => '',
    ),
  ),
  'gallery_images' => 
  array (
    0 => 
    array (
      'https://static.dafiti.com.ar/p/her-jeans-5029-972295-1-zoom.jpg'
    ),
    1 => 
    array (
      'https://static.dafiti.com.ar/p/her-jeans-5031-972295-2-zoom.jpg'
    ),
    2 => 
    array (
      'https://static.dafiti.com.ar/p/her-jeans-5032-972295-3-zoom.jpg'
    ),
    [
      'https://static.dafiti.com.ar/p/her-jeans-5033-972295-4-zoom.jpg'
    ]
  ),
  'attributes' => 
  array (
    'pa_color' => 
    array (
      'term_names' => 
      array (
        1 => 'azul',
        2 => 'blanco'
      ),
      'is_visible' => true,
    ),
    'pa_talla' => 
    array (
      'term_names' => 
      array (
        0 => 'xl',
        1 => 'l',
        2 => 'm',
        3 => '',
      ),
      'is_visible' => true,
    ),
  ),
  'default_attributes' => 
  array (
  ),
  'variations' => 
  array (
    0 => 
    array (
      'attributes' => 
      array (
        'attribute_pa_color' => 'azul',
        'attribute_pa_talla' => 'xl',
      ),
      'availability_html' => '<p class="stock in-stock">999 in stock</p>
',
      'backorders_allowed' => false,
      'dimensions' => 
      array (
        'length' => '20',
        'width' => '20',
        'height' => '20',
      ),
      'dimensions_html' => '10 &times; 10 &times; 10 cm',
      'display_price' => 69988.0,
      'display_regular_price' => 70088.0,
      'image' => 
      array (
        'full_src' => 'https://static.dafiti.com.ar/p/her-jeans-5031-972295-2-zoom.jpg',
      ),
      'is_downloadable' => false,
      'is_in_stock' => true,
      'is_purchasable' => true,
      'is_sold_individually' => 'yes',
      'is_virtual' => false,
      'max_qty' => 4,
      'min_qty' => 1,
      'price_html' => '<span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>700</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>699</bdi></span></ins></span>',
      'sku' => 'panta-azul',
      'variation_description' => 'nueva desc para el panta azul',
      'variation_id' => 36,
      'variation_is_active' => true,
      'variation_is_visible' => true,
      'weight' => '150',
      'weight_html' => '15 kg',
    ),
    1 => 
    array (
      'attributes' => 
      array (
        'attribute_pa_color' => 'blanco',
        'attribute_pa_talla' => '',
      ),
      'availability_html' => '<p class="stock in-stock">999 in stock</p>
',
      'backorders_allowed' => false,
      'dimensions' => 
      array (
        'length' => '10',
        'width' => '10',
        'height' => '10',
      ),
      'dimensions_html' => '10 &times; 10 &times; 10 cm',
      'display_price' => 489.0,
      'display_regular_price' => 500.0,
      'image' => 
      array (
        'title' => 'pantalonELBA_HUPIT1-scaled-700x1050',
        'caption' => '',
        'url' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1.jpg',
        'alt' => '',
        'src' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-600x900.jpg',
        'srcset' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-600x900.jpg 600w, http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-200x300.jpg 200w, http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-683x1024.jpg 683w, http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1.jpg 700w',
        'sizes' => '(max-width: 600px) 100vw, 600px',
        'full_src' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1.jpg',
        'full_src_w' => 700,
        'full_src_h' => 1050,
        'gallery_thumbnail_src' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-100x100.jpg',
        'gallery_thumbnail_src_w' => 100,
        'gallery_thumbnail_src_h' => 100,
        'thumb_src' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-300x300.jpg',
        'thumb_src_w' => 300,
        'thumb_src_h' => 300,
        'src_w' => 600,
        'src_h' => 900,
      ),
      'image_id' => 33,
      'is_downloadable' => false,
      'is_in_stock' => true,
      'is_purchasable' => true,
      'is_sold_individually' => 'no',
      'is_virtual' => false,
      'max_qty' => 999,
      'min_qty' => 1,
      'price_html' => '<span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>500</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>489</bdi></span></ins></span>',
      'sku' => '',
      'variation_description' => '<p>un ofertón!</p>
',
      'variation_id' => 35,
      'variation_is_active' => true,
      'variation_is_visible' => true,
      'weight' => '15',
      'weight_html' => '15 kg',
    ),
  ),
)
;