<?php

/*
	Settings
*/

#
# La API KEY debe coincidir con la del plugin Reactor
#
return [
	'API_KEY' => '9cbe0ce48e8c9FX',
	'status_at_creation' => 'draft'
];
