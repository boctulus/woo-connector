<?php

/*
	Settings
*/

#
# La API KEY debe coincidir con la del plugin Reactor
#
return [
	'status_at_creation' => 'draft',
	'test_mode' => false
];
