<?php

array (
  'data' => 
  array (
    0 => 
    array (
      'id' => 63,
      'type' => 'simple',
      'name' => 'Ooooo',
      'slug' => 'ooooo',
      'status' => 'publish',
      'featured' => false,
      'catalog_visibility' => 'visible',
      'description' => 'oooooo',
      'short_description' => 'short',
      'sku' => 'ooo-1',
      'price' => '',
      'regular_price' => '',
      'sale_price' => '',
      'manage_stock' => false,
      'stock_quantity' => NULL,
      'stock_status' => 'instock',
      'is_sold_individually' => false,
      'weight' => '',
      'length' => '',
      'width' => '',
      'height' => '',
      'parent_id' => 0,
      'tags' => 
      array (
      ),
      'categories' => 
      array (
        0 => 
        array (
          'name' => 'Nova catego',
          'slug' => 'nova-catego',
          'description' => '',
        ),
      ),
      'image' => 
      array (
        0 => 'http://woo2.lan/wp-content/uploads/2021/07/pocketpantswhite_mariamalo4-683x1024.jpg',
        1 => 683, 
        2 => 1024,
        3 => true,
      ),
      'gallery_images' => 
      array (
        0 => 
        array (
          0 => 'http://woo2.lan/wp-content/uploads/2021/08/Camisa-Manga-Larga-Columbia-Silver-Ridge-Trekking-Hombre-Carbon-AM7453-469.jpg',
          1 => 500,
          2 => 500,
          3 => false,
        ),
        1 => 
        array (
          0 => 'http://woo2.lan/wp-content/uploads/2021/07/pocketpantswhite_mariamalo4-683x1024.jpg',
          1 => 683,
          2 => 1024,
          3 => true,
        ),
      ),
      'attributes' => 
      array (
        'pa_talla' => 
        array (
        ),
        'pa_color' => 
        array (
        ),
      ),
      'operation' => 'UPDATE',
    ),
  ),
  'http_code' => 200,
  'error' => '',
);
