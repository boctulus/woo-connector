<?php

/*
  WooCommerce
*/

$res = array (
  'data' => 
  array (
    0 => 
    array (
      'id' => 66,
      'type' => 'variable',
      'name' => 'Shopi-like product',
      'slug' => '',
      'status' => 'draft',
      'featured' => false,
      'catalog_visibility' => 'visible',
      'description' => 'bla bla',
      'short_description' => 'short',
      'sku' => 'asdf',
      'price' => '789',
      'regular_price' => '',
      'sale_price' => '',
      'manage_stock' => false,
      'stock_quantity' => NULL,
      'stock_status' => 'instock',
      'is_sold_individually' => false,
      'weight' => '',
      'length' => '',
      'width' => '',
      'height' => '',
      'parent_id' => 0,
      'tags' => 
      array (
      ),
      'categories' => 
      array (
        0 => 
        array (
          'name' => 'Pantalones',
          'slug' => 'pantalones',
          'description' => '',
        ),
      ),
      'image' => 
      array (
        0 => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-683x1024.jpg',
        1 => 683,
        2 => 1024,
        3 => true,
      ),
      'gallery_images' => 
      array (
        0 => 
        array (
          0 => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-683x1024.jpg',
          1 => 683,
          2 => 1024,
          3 => true,
        ),
      ),
      'attributes' => 
      array (
        'pa_talla' => 
        array (
          'term_names' => 
          array (
            's',
            'm',
            'l',
            'xl'
          ),
          'is_visible' => true,
        ),
      ),
      'default_attributes' => 
      array (
        'pa_talla' => 'l',
      ),
      'variations' => 
      array (
        0 => 
        array (
          'attributes' => 
          array (
            'attribute_pa_talla' => 'l',
          ),
          'availability_html' => '',
          'backorders_allowed' => false,
          'dimensions' => 
          array (
            'length' => '',
            'width' => '',
            'height' => '',
          ),
          'dimensions_html' => 'N/A',
          'display_price' => 789,
          'display_regular_price' => 789,
          'image' => 
          array (
            'title' => 'pantalonELBA_HUPIT1-scaled-700x1050',
            'caption' => '',
            'url' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1.jpg',
            'alt' => '',
            'src' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-600x900.jpg',
            'srcset' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-600x900.jpg 600w, http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-200x300.jpg 200w, http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-683x1024.jpg 683w, http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1.jpg 700w',
            'sizes' => '(max-width: 600px) 100vw, 600px',
            'full_src' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1.jpg',
            'full_src_w' => 700,
            'full_src_h' => 1050,
            'gallery_thumbnail_src' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-100x100.jpg',
            'gallery_thumbnail_src_w' => 100,
            'gallery_thumbnail_src_h' => 100,
            'thumb_src' => 'http://woo2.lan/wp-content/uploads/2021/07/pantalonELBA_HUPIT1-scaled-700x1050-1-300x300.jpg',
            'thumb_src_w' => 300,
            'thumb_src_h' => 300,
            'src_w' => 600,
            'src_h' => 900,
          ),
          'image_id' => 33,
          'is_downloadable' => false,
          'is_in_stock' => true,
          'is_purchasable' => false,
          'is_sold_individually' => 'no',
          'is_virtual' => false,
          'max_qty' => '',
          'min_qty' => 1,
          'price_html' => '',
          'sku' => '',
          'variation_description' => '',
          'variation_id' => 67,
          'variation_is_active' => true,
          'variation_is_visible' => true,
          'weight' => '',
          'weight_html' => 'N/A',
        ),
      ),
      'operation' => 'UPDATE',
    ),
  ),
  'http_code' => 200,
  'error' => '',
);
